-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2023 at 07:35 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `Usernames` text NOT NULL,
  `EmailId` text NOT NULL,
  `pwds` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `Usernames`, `EmailId`, `pwds`) VALUES
(1, '', '', '$2y$10$m4DW6HmzG5yTNglP0PqRxOjAmbzFwWhLbTUslapGASjPQtTyLo43C');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_name` text DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `city` text DEFAULT NULL,
  `RollNo` int(30) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `Updateddate` datetime DEFAULT NULL,
  `mobileno` text DEFAULT NULL,
  `IsDelete` tinyint(1) DEFAULT NULL,
  `file_path` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_name`, `age`, `city`, `RollNo`, `CreatedDate`, `Updateddate`, `mobileno`, `IsDelete`, `file_path`) VALUES
(1, 'Abhishek Bhosle', 25, 'Bhose', 101, '2021-04-23 11:44:38', NULL, NULL, 0, ''),
(2, 'Aniket Kavathekar', 25, 'Miraj', 102, '2021-05-21 02:44:38', NULL, NULL, 0, ''),
(4, 'Harshad Pawar', 26, 'Jununi', 103, '2021-07-24 22:44:38', NULL, NULL, 0, ''),
(5, 'Shubham Bhosale', 20, 'Miraj', 104, '2021-09-02 03:30:38', NULL, NULL, 0, ''),
(6, 'neha lingam', 25, 'pune', 107, '2022-04-23 01:46:38', '2022-09-04 18:47:12', '9878675645', 1, ''),
(7, 'pranali surve', 22, 'kolhapur', 108, '2022-09-04 15:10:53', NULL, NULL, 0, ''),
(10, 'sunita kale', 22, 'kolhapur', 109, '2022-09-04 15:45:09', NULL, '', 0, ''),
(11, 'sunita more', 21, 'jat', 110, '2022-09-04 15:48:38', NULL, '', 0, ''),
(12, 'sunita kele', 21, 'jat', 110, '2022-09-04 15:51:22', NULL, '9876876790', 0, ''),
(13, 'sunita nale', 21, 'bhose', 111, '2022-09-04 15:53:18', NULL, '9876876700', 0, ''),
(14, 'sunita nurle', 21, 'bhose', 111, '2022-09-04 15:53:50', NULL, '9876876700', 0, ''),
(15, 'priyanka jhoshi', 29, 'channai', 114, '2022-09-04 16:25:32', NULL, '9676876900', 1, ''),
(16, 'priyanka jhoshi', 29, 'channai', 114, '2022-09-04 16:25:55', NULL, '9676876900', 1, ''),
(17, 'priyanka jhoshi', 18, 'karnatak', 116, '2022-09-04 16:28:20', NULL, '9899876700', 0, ''),
(18, 'priyanka jhoshi', 18, 'karnatak', 116, '2022-09-04 16:32:46', NULL, '', 0, ''),
(19, 'priyanka jhoshi', 18, 'karnatak', 116, '2022-09-04 16:37:39', NULL, '', 0, ''),
(20, 'priyanka koli', 20, 'Delhi', 120, '2022-09-04 18:55:43', NULL, '', 0, ''),
(21, 'priyanka koli', 20, 'Delhi', 120, '2022-09-04 18:59:51', NULL, '', 0, ''),
(22, 'priyanka koli', 20, 'Delhi', 120, '2022-09-04 19:00:10', NULL, '', 0, ''),
(23, 'priyanka koli', 20, 'Delhi', 120, '2022-09-04 19:02:28', NULL, '8988876000', 0, 'http://localhost/newapi/uploads/../uploads/8ea86fa26c.png'),
(24, 'priyanka kuru', 22, 'New Delhi', 121, '2022-09-04 19:03:26', NULL, '9989876000', 0, ''),
(25, 'priyanka kuru', 22, 'New Delhi', 121, '2022-09-04 19:03:29', NULL, '9989876000', 0, ''),
(26, 'priyanka kuru', 22, 'New Delhi', 121, '2022-09-04 19:03:56', NULL, '9989876000', 0, 'http://localhost/newapi/uploads/../uploads/8ea86fa26c.png'),
(27, 'priyanka kuru', 22, 'New Delhi', 121, '2022-09-04 19:04:48', NULL, '9989871010', 0, 'http://localhost/newapi/uploads/../uploads/boot.png'),
(28, 'natasha', 22, 'New Delhi', 121, '2023-03-29 12:09:35', NULL, '9807898010', 0, 'http://localhost/newapi/uploads/../uploads/boot.png'),
(29, 'radhe', 20, 'Miraj', 200, '2023-04-03 11:11:50', NULL, '866845777', 0, 'http://localhost/newapi/uploads/../uploads/avatar7.png'),
(30, 'krishna', 20, 'kolhapur', 206, '2023-04-03 11:15:01', NULL, '8976787666', 0, 'http://localhost/newapi/uploads/../uploads/avatar7.png'),
(31, 'krishnaRadha', 20, 'kolhapur', 208, '2023-04-03 11:20:01', NULL, '8976787555', 0, 'http://localhost/newapi/uploads/../uploads/avatar7.png'),
(32, 'Radhakrishna', 22, 'kolhapur', 205, '2023-04-03 11:31:47', NULL, '8976787333', 0, 'http://localhost/newapi/uploads/../uploads/avatar7.png'),
(33, 'abhiabhi', 20, 'kolhapur', 300, '2023-04-03 20:40:28', NULL, '8976787444', 0, 'http://localhost/newapi/uploads/../uploads/avatar7.png'),
(34, 'abhiabhi', 20, 'kolhapur', 300, '2023-04-03 20:40:35', NULL, '8976787444', 0, 'http://localhost/newapi/uploads/../uploads/download (1).jpg'),
(35, 'abhiabhis', 20, 'kolhapur', 301, '2023-04-03 20:41:50', NULL, '8976787445', 0, ''),
(36, 'abhiabhiss', 20, 'kolhapur', 302, '2023-04-03 20:43:25', NULL, '8976787446', 0, 'http://localhost/newapi/uploads/../uploads/46a9ec8e5734d48770f26f1061708803--nine-durso-foxes.jpg'),
(37, 'Radhes', 20, 'kolhapur', 303, '2023-04-03 20:47:07', NULL, '8976787447', 0, 'http://localhost/newapi/uploads/../uploads/download (1).jpg'),
(38, 'natasha', 22, 'New Delhi', 121, '2023-04-03 20:59:22', NULL, '9807898010', 0, 'http://localhost/newapi/uploads/../uploads/download (1).jpg'),
(39, 'krishnasudama', 20, 'Miraj', 312, '2023-04-03 21:07:50', NULL, '8976787222', 0, 'http://localhost/newapi/uploads/../uploads/download (1).jpg'),
(40, 'srush', 20, 'malwadi', 224, '2023-04-03 22:17:20', NULL, '8976787549', 0, 'http://localhost/newapi/uploads/46a9ec8e5734d48770f26f1061708803--nine-durso-foxes.jpg'),
(41, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://localhost/newapi/../uploads/46a9ec8e5734d48770f26f1061708803--nine-durso-foxes.jpg46a9ec8e5734d48770f26f1061708803--nine-durso-foxes.jpg'),
(42, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://localhost/newapi/../uploads/3240.png_300.png3240.png_300.png'),
(43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://localhost/newapi/../uploads/avatar7.pngavatar7.png'),
(44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://localhost/newapi/../uploads/46a9ec8e5734d48770f26f1061708803--nine-durso-foxes.jpg46a9ec8e5734d48770f26f1061708803--nine-durso-foxes.jpg.webp'),
(45, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://localhost/newapi/../uploads/46a9ec8e5734d48770f26f1061708803--nine-durso-foxes.jpg46a9ec8e5734d48770f26f1061708803--nine-durso-foxes.jpg'),
(46, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://localhost/newapi/../uploads/46a9ec8e5734d48770f26f1061708803--nine-durso-foxes.jpg46a9ec8e5734d48770f26f1061708803--nine-durso-foxes.jpg'),
(47, 'Radhesakshar', 20, 'Miraj', 234, '2023-04-17 19:47:33', NULL, '8976787444', 0, ''),
(48, 'Radheghfhgfh', 20, 'kolhapur', 200, '2023-06-02 23:08:19', NULL, '8976787908', 0, ''),
(49, 'Radheghfhgfh', 20, 'kolhapur', 200, '2023-06-02 23:08:21', NULL, '8976787908', 0, ''),
(50, 'Radheghfhgfh', 20, 'kolhapur', 200, '2023-06-02 23:08:24', NULL, '8976787908', 0, ''),
(51, 'Radheghfhgfh', 20, 'kolhapur', 200, '2023-06-02 23:08:24', NULL, '8976787908', 0, ''),
(52, 'Radheghfhgfh', 20, 'kolhapur', 200, '2023-06-02 23:08:25', NULL, '8976787908', 0, ''),
(53, 'Radheghfhgfh', 20, 'kolhapur', 200, '2023-06-02 23:08:25', NULL, '8976787908', 0, ''),
(54, 'Radheghfhgfh', 20, 'kolhapur', 200, '2023-06-02 23:08:25', NULL, '8976787908', 0, ''),
(55, 'Radheghfhgfh', 20, 'kolhapur', 200, '2023-06-02 23:08:25', NULL, '8976787908', 0, ''),
(56, 'Radheghfhgfh', 20, 'kolhapur', 200, '2023-06-02 23:08:25', NULL, '8976787908', 0, ''),
(57, 'Radheghfhgfh', 20, 'kolhapur', 200, '2023-06-02 23:08:31', NULL, '8976787908', 0, ''),
(58, 'Radheghfhgfh', 20, 'kolhapur', 200, '2023-06-02 23:08:31', NULL, '8976787908', 0, ''),
(59, 'Radheghfhgfh', 20, 'kolhapur', 200, '2023-06-02 23:08:31', NULL, '8976787908', 0, ''),
(60, 'Radheghfhgfh', 20, 'kolhapur', 200, '2023-06-02 23:08:31', NULL, '8976787908', 0, ''),
(61, 'Radheghfhgfh', 20, 'kolhapur', 200, '2023-06-02 23:08:32', NULL, '8976787908', 0, ''),
(62, 'Radheghfhgfh', 29, 'kolhapuo', 278, '2023-06-02 23:08:43', NULL, '8976787908', 0, ''),
(63, 'Radheghfhgfh', 29, 'kolhapuo', 278, '2023-06-02 23:08:43', NULL, '8976787908', 0, ''),
(64, 'Radheghfhgfh', 29, 'kolhapuo', 278, '2023-06-02 23:08:44', NULL, '8976787908', 0, ''),
(65, 'Radheghfhgfh', 29, 'kolhapuo', 278, '2023-06-02 23:08:44', NULL, '8976787908', 0, ''),
(66, 'Radheghfhgfh', 29, 'kolhapuo', 278, '2023-06-02 23:08:44', NULL, '8976787908', 0, ''),
(67, 'Radheghfhgfh', 29, 'kolhapuo', 278, '2023-06-02 23:08:44', NULL, '8976787908', 0, ''),
(68, 'Radheghfhgfh', 29, 'kolhapuo', 278, '2023-06-02 23:08:44', NULL, '8976787908', 0, ''),
(69, 'Radheghfhgfh', 29, 'kolhapuo', 278, '2023-06-02 23:08:45', NULL, '8976787908', 0, ''),
(70, 'Radheghfhgfh', 29, 'kolhapuo', 278, '2023-06-02 23:08:45', NULL, '8976787908', 0, ''),
(71, 'Radhehghjg', 22, 'kolhapur', 200, '2023-06-02 23:09:17', NULL, '8976787898', 0, ''),
(72, 'Radhehghjg', 22, 'kolhapur', 200, '2023-06-02 23:09:18', NULL, '8976787898', 0, ''),
(73, 'Radhehghjg', 22, 'kolhapur', 200, '2023-06-02 23:09:19', NULL, '8976787898', 0, ''),
(74, 'Radhehghjg', 22, 'kolhapur', 200, '2023-06-02 23:09:19', NULL, '8976787898', 0, ''),
(75, 'Radhehghjg', 22, 'kolhapur', 200, '2023-06-02 23:09:19', NULL, '8976787898', 0, ''),
(76, 'Radhehghjg', 22, 'kolhapur', 200, '2023-06-02 23:09:19', NULL, '8976787898', 0, ''),
(77, 'neha lingam', 33, 'sangli', 270, '2023-06-03 17:07:40', '2023-06-03 22:17:52', '9878675666', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `Id` int(11) NOT NULL,
  `FirstName` varchar(200) NOT NULL,
  `LastName` varchar(200) NOT NULL,
  `MobileNo` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `Addresess` varchar(250) DEFAULT NULL,
  `IsDelete` tinyint(1) NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `UserRole` varchar(100) NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Updateddate` datetime NOT NULL DEFAULT current_timestamp(),
  `userfile_path` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`Id`, `FirstName`, `LastName`, `MobileNo`, `email`, `password`, `Addresess`, `IsDelete`, `IsActive`, `UserRole`, `CreatedDate`, `Updateddate`, `userfile_path`) VALUES
(5, '', '', 'priyanka kuru', 'new@gmail.com', '1234567', NULL, 0, 0, '', '2023-03-30 03:31:11', '2023-04-06 09:15:08', ''),
(6, '', '', 'priyanka kuru', 'new@gmail.com', '1234567', NULL, 0, 0, '', '2023-03-30 03:31:11', '2023-04-06 09:15:08', ''),
(7, '', '', 'priyanka kuru', 'new@gmail.com', '1234567', NULL, 0, 0, '', '2023-03-30 03:31:11', '2023-04-06 09:15:08', ''),
(8, '', '', 'abhi', 'abhi@gmail.com', '1234567', NULL, 0, 0, '', '2023-03-30 03:31:11', '2023-04-06 09:15:08', ''),
(9, '', '', 'navin', 'navin@gmail.com', '1234567', NULL, 0, 0, '', '2023-03-30 03:31:11', '2023-04-06 09:15:08', ''),
(10, '', '', 'sunita', 'sunita@gmail.com', '1234567', NULL, 0, 0, '', '2023-03-30 03:31:11', '2023-04-06 09:15:08', ''),
(11, 'suchita', 'yallapa', '9678546766', 'suchita5@myportal.com', '$2y$10$KieXOEBMA4h3FNalctS.BuVAfZzEJfobCafJ0pH/uC.bVSmtRtcOi', 'kolhapur near by ganpati mandir', 0, 0, 'jr.Teacher', '2023-04-06 02:41:59', '2023-04-06 09:15:08', ''),
(12, '', '', 'sruhti', 'sruhti@gmail.com', '$2y$10$0syTS.KPITTrq93iCzQ.eOxskU5t/VUybcuw8PwLuyC2ajG.8ugF2', NULL, 0, 0, '', '2023-04-06 20:18:36', '2023-04-06 09:15:08', ''),
(13, 'abhishek', 'shankar', '9187656476', 'abhishek@gmail.com', '$2y$10$NJN71GsjHDiVZckv4sYOiemm9fOhU3rACrnWYykwXNrlgaW5Qt/PO', 'shakar nager kolhapur', 0, 0, 'clark', '2023-04-06 20:20:01', '2023-04-06 09:15:08', 'http://localhost/newapi/uploads/../uploads/avatar7.png'),
(14, '', '', '19', 'suki@gmail.com', '$2y$10$xVhQdsqhsMVMJNXRkxtk.OeKVIueQn6gLFVPKUttTQ4p/dVv0C0VW', NULL, 0, 0, '', '2023-03-30 03:31:11', '2023-04-06 09:15:08', ''),
(15, '', '', 'nirmala7', 'nirmala@gmail.com', '$2y$10$N91lluoZFi.A5tH/2H9n7urs1lz48mGJSxzalPeEcaffmoDF.aTLy', NULL, 0, 0, '', '2023-03-30 03:31:11', '2023-04-06 09:15:08', ''),
(16, '', '', 'srushti@3', 'srushtiK@gmail.com', '$2y$10$nzSxr6mX9s8PWxzzjylvC.0h.GIrmrA3oh9dn9aATFopHoAxZtBYW', NULL, 0, 0, '', '2023-03-30 03:31:11', '2023-04-06 09:15:08', ''),
(17, 'John', 'Doe', '1234567890', 'JohnDoe@myportal.com', '$2y$10$ByHJUooaHNhOoDrb4FHj3eyQPtNW.fqbDTemRWLPJJzbDDUdmlPyW', 'Near by 100 ft road sangli', 0, 1, 'TEACHER', '2023-04-06 08:10:37', '2023-04-06 09:15:08', 'http://localhost/newapi/uploads/../uploads/20220725_202244_0000.png'),
(18, 'new', 'jonny', '8668457006', 'newjonny55@myportal.com', '$2y$10$4NZmMZPG443dfDxL1wZ6QuNDEj0QlIEzJp3yVux0sQDCIu9wUaCue', 'gajanan housing society chndanwadi', 0, 1, 'TEACHER', '2023-06-02 18:57:36', '2023-06-03 00:27:36', 'http://localhost/newapi/uploads/../uploads/3240.png_300.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
